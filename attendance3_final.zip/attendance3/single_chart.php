
<!doctype html>
<html>
<?php
include 'database.php';
$id = $_GET['id'];
$name = $_GET['name'];
?>
<head>
	<title>Line Chart</title>
	<script src="Chart.min.js"></script>
	<script src="utils.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.slim.min.js"></script>

	<style>
	canvas{
		-moz-user-select: none;
		-webkit-user-select: none;
		-ms-user-select: none;
	}
	</style>
</head>

<body>
	<div style="width:75%;">
    <a href = "show_student.php?id=<?php echo $id; ?>&name=<?php echo $name; ?>"><?php echo $name; ?></a>
		<canvas id="canvas"></canvas>

       


	</div>
	<br>

	<script>
		var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var config = {
			type: 'line',
			data: {
				labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
				datasets: [{
					label: 'Apprenant',
					backgroundColor: window.chartColors.orange,
					borderColor: window.chartColors.orange,
					data: [
                        <?php
                        //Get value of January
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id = '".$_GET['id']."' AND month = '1'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                            $amont = $getdata['points'];
                            echo $amont;
                            }else{
                            echo 0;
                            }
                        ?>,
						<?php
                        //Get value of February
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '2'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
						<?php
                        //Get value of March
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '3'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
						<?php
                        //Get value of April
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '4'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
						<?php
                        //Get value of May
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '5'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
						<?php
                        //Get value of June
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '6'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
<?php
                        //Get value of July
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '7'  ");
                        $getdata= mysqli_fetch_assoc($querydata);
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,



						<?php
                        //Get value of August
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '8'  ");
                        $getdata= mysqli_fetch_assoc($querydata);
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,


                        <?php
                        //Get value of September
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '9'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
                        <?php
                        //Get value of October
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '10'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
                        <?php
                        //Get value of November
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '11'  ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>,
                        <?php
                        //Get value of December
                        $querydata= mysqli_query($conn, "SELECT * FROM single_chart WHERE s_id='".$_GET['id']."' AND month = '12' ");
                        $getdata= mysqli_fetch_assoc($querydata); 
                        $rows = mysqli_num_rows($querydata);
                        if($rows==1){ 
                        $amont = $getdata['points'];
                        echo $amont;
                        }else{
                        echo 0;
                        }
                        ?>
                        
					],
					fill: false,
				}, ]
			},
			options: {
				responsive: true,
				title: {
					display: true,
					text: 'Présence annuelle'
				},
				tooltips: {
					mode: 'index',
					intersect: false,
				},
				hover: {
					mode: 'nearest',
					intersect: true
				},
				scales: {
					xAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Month'
						}
					}],
					yAxes: [{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'pesence'
						}
					}]
				}
			}
		};

		window.onload = function() {
			var ctx = document.getElementById('canvas').getContext('2d');
			window.myLine = new Chart(ctx, config);
		};

		
		var colorNames = Object.keys(window.chartColors);
		

		

		
		
	</script>
</body>

</html>
