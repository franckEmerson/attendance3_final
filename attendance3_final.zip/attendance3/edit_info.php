<?php
    require_once 'database.php';
    $result = mysqli_query($conn, "SELECT * FROM tbl_absent WHERE student_id='".$_GET["id"]."' AND absent_date = '".$_GET["date"]."' ");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Justify</title>
</head>
<body>
    <h1>Absent justify by:</h1>
    <form method="post">
        <?php if(mysqli_num_rows($result) != 0){
            while($r = mysqli_fetch_assoc($result)):
         ?>
        <input type="text" name="justify" placeholder="Cause absence" value="<?php echo $r["motif_absence"];?>">
        <?php endwhile; }?>
        <input type="submit" name="submit" value="submit">
    </form>
    <?php

        if(isset($_POST["submit"]) && !empty($_POST["justify"])){

            $a = mysqli_query($conn, "UPDATE tbl_absent SET motif_absence = '".$_POST["justify"]."' WHERE student_id='".$_GET["id"]."' AND absent_date ='".$_GET["date"]."'  ");
            if($a){echo "<script>alert('Absence modifiée avec succès')</script>";
                echo "  <a class='btn btn-danger btn-sm' id='register' href='index.php'>OK</a> ";}
            if(!$a){echo "Erreur";}
        }
        
    ?>
</body>
</html>