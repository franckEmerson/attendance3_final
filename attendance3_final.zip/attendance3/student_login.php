<?php
    session_start();
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'taken';
    $conn = mysqli_connect($host, $user, $pass, $db);

    $id = $_SESSION["id"];
    $result = mysqli_query($conn, "SELECT * FROM users WHERE id='$id' ");
    if(!$result){echo "Erreur";}
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="style.css">

</head>
    <body class="container bg-light">
    <br>
    <br>
    <br>
    
        
        </div>
    <div class="row bg-secondary text-light">
        <?php while($row= mysqli_fetch_array($result)): ?>
        <div class="col-3 p-2"> Apprenant :<strong> <?php echo $row["username"]; ?></strong></div>
        <div class="col p-2"></div>
        <a href="logout.php" class="col-1 p-1 d-flex flex-reverse btn btn-lg btn-primary">Logout</a>
        <a href="#" class="btn btn-success btn-sm" id="editer" >Back</a><br/></div>
    </div>
    
        <br>

    <div class="container emp-profile">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="profile-img">
                                <img src="<?php echo $row["file_name"] ?>" class="img-responsive img-thumbnail" width="200">;
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="tab-content profile-tab" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

            
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>User name :</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><?php echo $row["username"]; ?></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>Email :</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><?php echo $row["email"]; ?></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>Mot de passe :</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <p>Votre mot de passe</p>
                                                </div>
                                            </div>
                                    
                                </div>
                        
                    </div>
                    <?php endwhile ?>
                    
                </div>
                <table align="center">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Motif absence</th>
                        </tr>
                    </thead>
                        <?php
                            $req = mysqli_query($conn, "SELECT * FROM tbl_absent WHERE student_id='$id' ");
                            if(mysqli_num_rows($req) != 0){
                                while($r = mysqli_fetch_assoc($req)):?>
                    <tr>
                        <td><?php echo $r["absent_date"]; ?></td>
                        <td>
                            <?php echo $r["motif_absence"]."\t"; ?>
                        </td>
                    </tr>
                        <?php endwhile ;  }?>
                </table>
            </div>
        

    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    </body>
</html>



