<?php 
       session_start();
       $host = 'localhost';
       $user = 'root';
       $pass = '';
       $db = 'taken';
       $conn = mysqli_connect($host, $user, $pass, $db);
   
       $email = $_SESSION['email'];
       $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' ");
       if(!$result){echo "Erreur";}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance 3</title>
</head>
<body>

    <?php while($row= mysqli_fetch_array($result)): ?>
        <div align="center">
            <h2><strong>Editer profil</strong></h2>
            <form method="post">
                <input type="text" name="up_name" value="<?php echo $row["username"]; ?>"><br>
                <input type="submit" name="submit">
            </form>
            </div>
    <?php
            if(isset($_POST["submit"])){
                
                $nom = $_POST["up_name"];
                $id = $row["id"];
                $req=mysqli_query($conn, "UPDATE users SET username='$nom' WHERE id='$id' ");
                
                if(!$req){echo mysqli_error($conn);}
                else{header("Location:profil.php");}
            }

    ?>

    <?php endwhile ?>
</body>
</html>