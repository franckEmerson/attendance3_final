<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Student Attendance Menu</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="http://www.cssscript.com/wp-includes/css/sticky.css" rel="stylesheet" type="text/css">
<style>
nav {
  width: 80px;
  height: 80px;
  position: fixed;
  top: 150px;
  left: 40px;
  background: url("ecole.png") 0 0 no-repeat #242b33;
  -moz-background-size: 80px;
  -o-background-size: 80px;
  -webkit-background-size: 80px;
  background-size: 80px;
  border-radius: 4px;
  box-shadow: 0 2px 3px 0 rgba(0, 0, 0, 0.25);
  cursor: pointer;
  overflow: hidden;
}

nav ul { width: 400px; }

nav li {
  width: 200px;
  height: 200px;
  float: left;
  text-align: center;
  opacity: 0;
  -moz-transform: translateY(80px);
  -ms-transform: translateY(80px);
  -webkit-transform: translateY(80px);
  transform: translateY(80px);
}

nav a {
  display: block;
  width: 100%;
  height: 100%;
  font-family: 'Source Sans Pro';
  color: #fff;
  font-weight: 400;
  text-decoration: none;
}

nav i {
  display: block;
  width: 100px;
  height: 100px;
  margin: 40px auto 10px;
  background: center no-repeat;
  background-size: 100%;
}

nav .feed-btn i { background-image: url("connexion.png"); }

nav .profile-btn i {
  background-image: url("signer.png");
  background-size: 115%;
}

nav .draft-btn i { background-image: url("prof.png"); }

nav .signout-btn i { background-image: url("dashboard.png"); }

nav:hover {
  width: 400px;
  height: 400px;
  background-position: 0 -80px;
}

nav:hover li {
  opacity: 1;
  -moz-transform: translateY(0px);
  -ms-transform: translateY(0px);
  -webkit-transform: translateY(0px);
  transform: translateY(0px);
}

nav:hover li:hover { background: #394451; }

nav { transition: all 0.6s cubic-bezier(0.19, 1, 0.22, 1); }

nav li { transition: transform 0.6s cubic-bezier(0.19, 1, 0.22, 1), opacity 0.6s cubic-bezier(0.19, 1, 0.22, 1); }

nav li:nth-child(1) {
  -moz-transition-delay: 0.07s;
  -o-transition-delay: 0.07s;
  -webkit-transition-delay: 0.07s;
  transition-delay: 0.07s;
}

nav li:nth-child(2) {
  -moz-transition-delay: 0.14s;
  -o-transition-delay: 0.14s;
  -webkit-transition-delay: 0.14s;
  transition-delay: 0.14s;
}

nav li:nth-child(3) {
  -moz-transition-delay: 0.21s;
  -o-transition-delay: 0.21s;
  -webkit-transition-delay: 0.21s;
  transition-delay: 0.21s;
}

nav li:nth-child(4) {
  -moz-transition-delay: 0.28s;
  -o-transition-delay: 0.28s;
  -webkit-transition-delay: 0.28s;
  transition-delay: 0.28s;
}
</style>
<link href="reset.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="css-script-menu">
  <div class="css-script-center">
    <ul>
      <h1>Student Attendance 3</h1>
    </ul>
    <div class="css-script-ads"><script type="text/javascript">
google_ad_client = "ca-pub-2783044520727903";
/* CSSScript Demo Page */
google_ad_slot = "3025259193";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script> 
      <script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script></div>
    <div class="css-script-clear"></div>
  </div>
</div>
<nav>
  <ul>
    <li><a href="sentdata.php" class="feed-btn"><i></i>Inscription</a></li>
    <li><a href="signez.php" class="profile-btn"><i></i>Signer</a></li>
    <li><a href="teacher_index.php" class="draft-btn"><i></i>Proffesseur</a></li>
    <li><a href="student_login.php" class="signout-btn"><i></i>Apprenant</a></li>
  </ul>
</nav>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-46156385-1', 'cssscript.com');
  ga('send', 'pageview');

</script>
</body>
</html>
