<?php 
    $conn = mysqli_connect("localhost","root","","taken");
    $result = mysqli_query($conn, "SELECT * FROM graphe");
    if(!$result){echo "Erreur";}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Graphe De Presence</title>
    <style type="text/css">
      #chart-container {
        width: 640px;
        height: auto;
      }
        table {
            border-collapse: collapse;
        }
        table, td, th {
            border: 1px solid black;
        }
    </style>
  </head>
  <body>
    <div align="center">
      <h1>GRAPHE DE PRESENCE</h1>
    </div>
          <button><a href="index.php" class="btn btn-success btn-xs">Back</a></button>
          <button><a href="logout.php" class="btn btn-success btn-xs">Logout</a></button>
          
    <div id="chart-container">
      <canvas id="mycanvas"></canvas>
    </div>

	<table align="center">
        <thead>
            <tr>
                <th>Students</th>
                <th>Number</th>
            </tr>
        </thead>
        <?php while($row= mysqli_fetch_assoc($result)): ?>
            <tr>
                <td> <?php echo $row["student_name"]; ?> </td>
                <td> 
                    <?php echo $row["attendance_number"]."\t" ; ?><a href="show_student.php?id=<?php echo $row["student_id"]; ?>&name=<?php echo $row["student_name"]; ?>">more</a>
                </td>
            </tr>
        <?php endwhile ?>
    </table>

    <!-- javascript -->
    <script type="text/javascript" src="chart_js/jquery.min.js"></script>
    <script type="text/javascript" src="chart_js/Chart.min.js"></script>
    <script type="text/javascript" src="app.js"></script>
  </body>
</html>