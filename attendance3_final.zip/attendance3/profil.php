<?php
    session_start();
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'taken';
    $conn = mysqli_connect($host, $user, $pass, $db);

    $email = $_SESSION['email'];
    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' ");
    if(!$result){echo "Erreur";}
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <style>
        table {
            border-collapse: collapse;
        }
        table, td, th {
            border: 1px solid black;
        }
    </style>

</head>
<body class="container bg-light">
<br>
<br>
<br>
   
    
    </div>
<div class="row bg-secondary text-light">
  <div class="col-3 p-2">YOUR PROFIL</div>
  <div class="col p-2"></div>
  <a href="logout.php" class="col-1 p-1 d-flex flex-reverse btn btn-lg btn-primary">Logout</a>
                    <?php while($row= mysqli_fetch_array($result)):
                         $GLOBALS['id'] = $row['id']; /*On stocke l'id de l'apprenant dans une variable globale 'id' afin de l'utilisée à la ligne 119*/ 
                    ?>
  <a class="btn btn-success btn-sm" href="up_date_profil.php?edit=<?php echo $row['id']; ?>" >Edit profil</a><br/></div>
</div>
   
     <br>

<div class="container emp-profile">

                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <?php echo '<img src="'.$row["file_name"].'" class="img-responsive img-thumbnail" />';?>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

        
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>User name :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $row["username"]; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Email :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $row["email"]; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Phone :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $row["phone"]; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Sex :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p><?php echo $row["sex"]; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label>Mot de passe :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <p>Votre mot de passe</p>
                                            </div>
                                        </div>
                                
                            </div>
                    
                </div>
                <?php endwhile ?>
                
            </div>
        </div> 
        <!--Affichage du tableau d'abscence -->
        <table align="center">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Motif absence</th>
                </tr>
            </thead>
                <?php
                    $req = mysqli_query($conn, "SELECT * FROM tbl_absent WHERE student_id='$id' ");
                    if(mysqli_num_rows($req) != 0){
                        while($r = mysqli_fetch_assoc($req)):?>
                    <tr>
                        <td><?php echo $r["absent_date"]; ?></td>
                        <td><?php echo $r["motif_absence"]; ?></td>
                    </tr>
                <?php endwhile ;  }?>
        </table> 

    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
 
</body>
</html>



