-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 26 mars 2021 à 13:36
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `taken`
--

-- --------------------------------------------------------

--
-- Structure de la table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_name` varchar(60) NOT NULL,
  `month` varchar(60) NOT NULL,
  `attendance_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `attendance`
--

INSERT INTO `attendance` (`id`, `student_id`, `student_name`, `month`, `attendance_date`) VALUES
(1, 1, 'emerson kouame', '3', '2021-03-24');

-- --------------------------------------------------------

--
-- Structure de la table `graphe`
--

CREATE TABLE `graphe` (
  `id` int(11) NOT NULL,
  `attendance_number` int(60) NOT NULL,
  `student_name` varchar(60) NOT NULL,
  `student_id` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `graphe`
--

INSERT INTO `graphe` (`id`, `attendance_number`, `student_name`, `student_id`) VALUES
(3, 1, 'emerson kouame', 1);

-- --------------------------------------------------------

--
-- Structure de la table `single_chart`
--

CREATE TABLE `single_chart` (
  `points` int(60) NOT NULL,
  `s_id` int(60) NOT NULL,
  `month` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `single_chart`
--

INSERT INTO `single_chart` (`points`, `s_id`, `month`) VALUES
(6, 1, '3');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_absent`
--

CREATE TABLE `tbl_absent` (
  `id` int(11) NOT NULL,
  `student_id` int(60) NOT NULL,
  `absent_date` date NOT NULL,
  `motif_absence` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tbl_statut`
--

CREATE TABLE `tbl_statut` (
  `id` int(11) NOT NULL,
  `statut_du_cours` varchar(60) NOT NULL,
  `date_du_cours` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tbl_statut`
--

INSERT INTO `tbl_statut` (`id`, `statut_du_cours`, `date_du_cours`) VALUES
(2, '2', '2021-03-24');

-- --------------------------------------------------------

--
-- Structure de la table `tbl_teacher`
--

CREATE TABLE `tbl_teacher` (
  `id` int(11) NOT NULL,
  `teacher_name` varchar(60) NOT NULL,
  `teacher_email` varchar(60) NOT NULL,
  `teacher_password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`id`, `teacher_name`, `teacher_email`, `teacher_password`) VALUES
(2, 'ali', 'kouadiosilver2@gmail.com', '12345'),
(3, 'professeur', 'professeur@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `phone` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `sex` varchar(60) NOT NULL,
  `file_name` varchar(60) NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `statut_absence` int(11) NOT NULL,
  `date_du_cours` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `phone`, `email`, `password`, `sex`, `file_name`, `uploaded_on`, `statut_absence`, `date_du_cours`) VALUES
(1, 'emerson kouame', '12544788', 'franckemerson1@gmail.com', '12345', 'male', 'uploads/160619franck-emerson.jpg', '2021-03-24 00:40:31', 0, '0000-00-00'),
(2, 'emerson', '1254478', 'emer@gmail.com', '12345', 'male', 'uploads/20050franck.jpg', '2021-03-24 14:06:47', 0, '0000-00-00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `graphe`
--
ALTER TABLE `graphe`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_absent`
--
ALTER TABLE `tbl_absent`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_statut`
--
ALTER TABLE `tbl_statut`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `graphe`
--
ALTER TABLE `graphe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `tbl_absent`
--
ALTER TABLE `tbl_absent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tbl_statut`
--
ALTER TABLE `tbl_statut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
