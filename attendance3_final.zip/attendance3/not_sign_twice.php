<?php
    session_start();
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'taken';
    $conn = mysqli_connect($host, $user, $pass, $db);
    $date = date('Y-m-d');
    $m = date_parse_from_format("Y-m-d", $date);
    $moi_actuel = $m["month"]; //On stock le mois actuel afin de l'utiliser dans la condition single_graph=1 

    $s_id = $_SESSION["id"];
    
    $sql="select student_id from attendance where student_id='$s_id' and attendance_date='$date'";

    //tentative de selection de la datte du cours
    $req = mysqli_query($conn, "SELECT date_du_cours FROM users WHERE id = '$s_id' AND date_du_cours='$date'");


    
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deja signé</title>    
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>

    <?php
        
        if(mysqli_num_rows($req) == 0){//Si aucune datte de cours n'est trouvée
            echo "<script>alert('Pas de cours actif..')</script>";
            echo "  <a class='btn btn-danger btn-sm' id='register' href='logout.php'>OK</a> ";
        }
        else
        {
            $query = mysqli_query($conn, $sql);
            if(mysqli_num_rows($query)>0){ //On vérifie si on a déja signé
                echo "<script>alert('Vous avez déjâ signé')</script>";
                echo "  <a class='btn btn-danger btn-sm' id='register' href='logout.php'>OK</a> ";
            }
            else{
    
                $email = $_SESSION["email"];
                $sql=mysqli_query($conn,"select id, username, date_du_cours from users where email='$email'");
                $row = mysqli_fetch_assoc($sql);
                $id = $row["id"];
                $mois = $row['date_du_cours'];//Recupération de la date au format Y-m-d
                $current_month = date_parse_from_format("Y-m-d", $mois);//Analyse de la date à partir du format, dans le but de récuperer le mois de la date séléctionné
                
                //Insersion des données de l'apprenant dans la table de présence
                $inserer = "INSERT INTO attendance(student_id, student_name, month, attendance_date)VALUES('".$row["id"]."', '".$row["username"]."', '".$current_month["month"]."', '$date')";
                $maj = "UPDATE users SET statut_absence = 0 WHERE id = $s_id AND date_du_cours = '$date'";//MAJ du statut de l'absence à 0. (On est présent)
    
                if(mysqli_query($conn, $inserer)){
    
                    mysqli_query($conn, $maj);//Effectue la requêtte de la MAJ
                    
                    //Le code ci-dessous permet de compter le nombre de fois que l'apprenant a signer
                    $a = "SELECT * FROM graphe WHERE student_id='$id' ";
                    $b = mysqli_query($conn, $a);
                    $del = "DELETE FROM graphe WHERE student_id = '$id' ";
    
                    $g = "INSERT INTO graphe (attendance_number, student_name, student_id) 
                    SELECT COUNT(student_id), student_name, student_id  FROM attendance  WHERE student_id = '$id'
                    GROUP BY student_id
                    ORDER BY COUNT(student_id) ";
    
                    if (mysqli_num_rows($b) != 0 ) {
    
                        mysqli_query($conn, $del);
                        mysqli_query($conn, $g);
                        $single_graph = 1;
    
                    } elseif (mysqli_num_rows($b) == 0 ) {
    
                        $result_count = mysqli_query($conn,$g);
                        $single_graph = 1;
    
                    }


                    if($single_graph == 1){
                        //Gestion du graphe perso
                        $x = "SELECT * FROM single_chart WHERE s_id='$id' AND  month='$moi_actuel'";
                        $y = mysqli_query($conn, $x);
                        $delete = "DELETE FROM single_chart WHERE s_id = '$id' AND month='$moi_actuel'";
        
                        $z = "INSERT INTO single_chart (points, s_id, month) 
                        SELECT COUNT(student_id)+5, student_id, month  FROM attendance  WHERE student_id = '$id' AND month='$moi_actuel'
                        GROUP BY student_id ";
        
                        if (mysqli_num_rows($y) != 0 ) {
        
                            mysqli_query($conn, $delete);
                            mysqli_query($conn, $z);
        
                        } elseif (mysqli_num_rows($y) == 0 ) {
        
                            $result_count = mysqli_query($conn,$z);
        
                        }
                    }
                    
                }
    
                mysqli_close($conn);
                header("Location: bienvenue.php");
        
            }
        }

    ?>

</body>
</html>