<?php
    session_start();
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'taken';
    $conn = mysqli_connect($host, $user, $pass, $db);

    $query=mysqli_query($conn,"select * from attendance where student_id='$s_id'");
    
?>