<!DOCTYPE html>
<html>
    <head>
    <script type="text/javascript" src="js/jquery.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>Student Attendance2</title>
    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

    </head>
    <body>
        <div class="main">
            <section class="signup">
                <div class="container">
                    <div class="signup-content">
                        <div class="signup-form">
                            <h2 class="form-title">S'enregistrer</h2>
                            <form method="POST" action="checkdata.php" enctype="multipart/form-data" id="form" onsubmit="return checkall();">
                                <div class="form-group">
                                    <label for=""><i class="zmdi zmdi-account material-icons-name"></i></label>
                                    <input type="text" name="username" id="UserName" placeholder="Name">
                                </div>
                                <div class="form-group">
                                    <label for=""><i class="zmdi zmdi-email"></i></label>
                                    <input type="text" name="useremail" id="UserEmail" placeholder="Email" required onkeyup="checkemail();">
                                    <span id="email_status"></span>
                                </div>
                                <div class="form-group">
                                    <label for=""><i class="zmdi zmdi-phone"></i></label>
                                    <input type="tel" name="userphone" id="UserPhone" placeholder="Phone" onkeyup="checkphone();">
                                    <span id="phone_status"></span>
                                </div>
                                <div class="form-group">
                                    <label for=""><i class="zmdi zmdi-lock"></i></label>
                                    <input type="password" name="userpass" id="UserPassword" placeholder="Password (10 Max)" required maxlength="10" minlength="5">
                                </div>
                                <div class="form-group">
                                    <label for=""><i class="zmdi zmdi-lock-outline"></i></label>
                                    <input type="password" name="userpass2" id="UserPassword2" placeholder="Confirmer (10 Max)" required maxlength="10" onkeyup="checkpass();">
                                    <span id="pass_status"></span>
                                </div>
                                <div class="form-group">
                                    <input type="file" name="file"/>
                                </div>
                                <div class="form-group">
                                    <input type="radio" name="sex" id="agree-term" class="agree-term" value="male"checked />
                                    <label for="agree-term" class="label-agree-term">Mâle</label>
                                    
                                    <input type="radio" name="sex" id="agree-term" class="agree-term" value="femelle" />
                                    <label for="agree-term" class="label-agree-term">Femelle</label>
                                    
                                    <input type="radio" name="sex" id="agree-term" class="agree-term" value="autre" />
                                    <label for="agree-term" class="label-agree-term">Autre</label>
                                </div>
                                <div class="form-group form-button">
                                    <input type="submit" name="submit_form" class="form-submit" value="Enregistrer"/>
                                    <a href="main_menu.php">Acceuil</a>
                                </div>
                            </form>
                        </div>
                        <div class="signup-image">
                            <figure><img src="layout_img/signup-image.jpg" alt="sing up image"></figure>
                            <a href="signez.php" class="signup-image-link">Déjà membre</a>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>

    <script>

        function checkphone()//Fonction qui vérifie si le téléphone existe ou pas
        {
            var phone = document.getElementById( "UserPhone" ).value;
                
            if(phone)
            {
                $.ajax({
                    type: 'post',
                    url: 'checkdata.php',
                    data: {
                    user_phone:phone,
                    },
                    success: function (response) {
                        $( '#phone_status' ).html(response);
                        if(response=="OK")	
                        {
                            return true;	
                        }
                        else
                        {
                            return false;	
                        }
                    }
                });
            }
                else
                {
                    $( '#phone_status' ).html("");
                    return false;
                }
        }

        function checkemail()//Fonction qui vérifie si le mail existe ou pas
        {
        var email=document.getElementById( "UserEmail" ).value;
            
        if(email)
        {
            $.ajax({
                type: 'post',
                url: 'checkdata.php',
                data: {
                user_email:email,
                },
                success: function (response) {
                    $( '#email_status' ).html(response);
                    if(response=="OK")	
                    {
                        return true;	
                    }
                    else
                    {
                        return false;	
                    }
                }
            });
            }
            else
            {
                $( '#email_status' ).html("");
                return false;
            }
        }

        function checkpass()//Fonction qui vérifie si les Mdp correspondant
        {
            var pass2=document.getElementById( "UserPassword2" ).value;
            var pass=document.getElementById( "UserPassword" ).value;
                
            if(pass2)
            {
                $.ajax({
                    type: 'post',
                    url: 'checkdata.php',
                    data: {
                    user_pass2:pass2,
                    user_pass:pass,
                    },
                    success: function (response) {
                        $( '#pass_status' ).html(response);
                        if(response=="OK")	
                        {
                            return true;	
                        }
                        else
                        {
                            return false;	
                        }
                    }
                });
            }
                else
                {
                    $( '#pass_status' ).html("");
                    return false;
                }
        }


        function checkall()
        {
            var namehtml=document.getElementById("phone_status").innerHTML;
            var emailhtml=document.getElementById("email_status").innerHTML;
            var passhtml=document.getElementById("pass_status").innerHTML;

            if((namehtml && emailhtml && passhtml)=="OK")
            {
                return true;//On peut s'inscrire
            }
            else
            {
                return false;//On ne peut pas s'incrire
            }
        }



    </script>

    </body>
</html>