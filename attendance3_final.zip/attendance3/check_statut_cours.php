<?php 
    require_once 'database.php';
    $date = date('Y-m-d');

    if(isset($_GET['start'])){
        $req = mysqli_query($conn, "SELECT statut_du_cours FROM tbl_statut WHERE date_du_cours='$date'");

        if(mysqli_num_rows($req) == 0){
            $a = mysqli_query($conn, "INSERT INTO tbl_statut SET statut_du_cours='".$_GET['start']."', date_du_cours='$date'");
            $m = "UPDATE users SET date_du_cours='$date', statut_absence='".$_GET['start']."' ";
            if($a){
                mysqli_query($conn, $m);
                echo "<script>alert('Debut du cours..')</script>";//08898747 Père de seri
            }
        }
        else
        {
            $row = mysqli_fetch_assoc($req);
            if($row['statut_du_cours'] == 1){
                echo "<script>alert('Le cours à déja débuté..')</script>";
            }
            if($row['statut_du_cours'] == 2){
                echo "<script>alert('Le cours est terminé pour ajourdhui..')</script>";
            }
            
        }
        
    }

    if(isset($_GET['end'])){
        $req = mysqli_query($conn, "SELECT statut_du_cours FROM tbl_statut WHERE  date_du_cours='$date'");
        $row = mysqli_fetch_assoc($req);

        if(mysqli_num_rows($req) == 0){
            echo "<script>alert('Aucun cours en vu..')</script>";
        }
        else{

            if($row['statut_du_cours'] == 1){
                $b = "UPDATE tbl_statut SET statut_du_cours='".$_GET['end']."' ";//Mise à jour du statut_du_cours à 2 (Soit la fin du cours)
                
                $d = "INSERT INTO tbl_absent(student_id, student_name, absent_date) SELECT id, username, date_du_cours FROM users WHERE date_du_cours='$date' AND statut_absence = 1 ";//Insersion des données des absents dans la tbl_absent
                

                if(mysqli_query($conn, $b)){//Si la requête de mise à jour du statut (Fin du cours) du cours est OK
                    
                    mysqli_query($conn, $d);// On fait la requette de $d
                    mysqli_query($conn, "UPDATE users SET date_du_cours=NULL, statut_absence=0 ");// On remet la date à NULL et le statut du cours à 0
                    echo "<script>alert('Fin du cours..')</script>";
                }
            }
            elseif ($row['statut_du_cours'] == 2) {
                echo "<script>alert('Le cours est déja terminé..')</script>";
            }
            elseif ($row['statut_du_cours'] == 0){
                echo "<script>alert('Vous devez d'abord commencé le cours..')</script>";
            }

        }
    }
    echo "<a href='teacher_dashboard.php' class='btn btn-success btn-xs'>OK</a>";
    
?>