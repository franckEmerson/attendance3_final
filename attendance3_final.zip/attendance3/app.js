$(document).ready(function(){
  $.ajax({
    url: "chart_data2.php",
    method: "GET",
    success: function(data) {
      console.log(data);
      var student_name = [];
      var attendance_number = [];

      for(var i in data) {
        student_name.push(data[i].student_name);
        attendance_number.push(data[i].attendance_number);
      }

      var chartdata = {
        labels: student_name,
        datasets : [
          {
            label: 'Attendance',
            backgroundColor: '#49e2ff',
            borderColor: 'rgba(200, 200, 200, 0.75)',
            hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
            hoverBorderColor: 'rgba(200, 200, 200, 1)',
            data: attendance_number
          }
        ]
      };

      var ctx = $("#mycanvas");

      var barGraph = new Chart(ctx, {
        type: 'bar',
        data: chartdata
      });
    },
    error: function(data) {
      console.log(data);
    }
  });
});