<?php
    session_start();
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'taken';
    $conn = mysqli_connect($host, $user, $pass, $db);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deja signé</title>    
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
    <h1>Bien signé</h1><br>
    <SCRIPT LANGUAGE="JavaScript">
        var maintenant=new Date();
        document.write(maintenant);
    </SCRIPT>
    <a class="btn btn-success btn-sm" id="register" href="student_login.php">OK</a>
    

</body>
</html>