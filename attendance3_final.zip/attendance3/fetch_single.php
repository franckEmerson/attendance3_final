<?php

//fetch_single.php

include('database_connection.php');

if(isset($_GET["id"]))
{
 $query = "SELECT * FROM users WHERE id = '".$_GET["id"]."'";

 $statement = $connect->prepare($query);
 $statement->execute();
 $result = $statement->fetchAll();
 $output = '<div class="row">';
 foreach($result as $row)
 {
  $images = '';
  if($row["file_name"] != '')
  {
   $images = '<img src="'.$row["file_name"].'" class="img-responsive img-thumbnail" />';
  }
  else
  {
   $images = '<img src="https://www.gravatar.com/avatar/38ed5967302ec60ff4417826c24feef6?s=80&d=mm&r=g" class="img-responsive img-thumbnail" />';
  }
  $output .= '
  <div class="col-md-3">
   <br />
   '.$images.'
  </div>
  <div class="col-md-9">
   <br />
   <p><label>Name :&nbsp;</label>'.$row["username"].'</p>
   <p><label>Sexe :&nbsp;</label>'.$row["sex"].'</p>
   <p><label>Email :&nbsp;</label>'.$row["email"].'</p>
   <p><label>Phone :&nbsp;</label>'.$row["phone"].'</p>
  </div>
  </div><br />
  ';
 }
 echo $output;
}

?>