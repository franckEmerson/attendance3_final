<?php session_start();

  include_once('database.php');
  $email = $_SESSION['email'];
  $result = mysqli_query($conn, "SELECT * FROM tbl_teacher WHERE teacher_email='$email' ");
   if(!$result){echo "Erreur";}
   else{
    $row = mysqli_fetch_assoc($result);
    $nometprenoms = $row['teacher_name'];
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/7cb0e7c261.js" crossorigin="anonymous"></script>
 
  <style>

    body {font-family: "Lato", sans-serif;}

    .sidebar {
      height: 100%;
      width: 180px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #3E844A;
      overflow-x: hidden;
      padding-top: 16px;
    }

    .sidebar a {
      padding: 6px 8px 6px 16px;
      text-decoration: none;
      font-size: 15px;
      color: #FFFFFF;
      display: block;
    }

    .sidebar a:hover {
      color: #183B14;
    }

    .main {
      margin-left: 180px; 
      padding: 0px 10px;
    }

    @media screen and (max-height: 450px) {
      .sidebar {padding-top: 15px;}
      .sidebar a {font-size: 18px;}
    }


    .chip {
        display: inline-block;
        padding: 0 80px;
        height: 50px;
        font-size: 16px;
        line-height: 50px;
        border-radius: 25px;
        background-color: #000000;
    }

    .chip img {
        float: left;
        margin: 0 10px 0 -80px;
        height: 50px;
        width: 50px;
        border-radius: 50%;
    }

  table {font-size: 13px;}

  thead {font-weight: bold;}

</style>
</head>

<body>

  <div class="sidebar ">
    <br><br><a href="#dashboard"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard</a><br><br><br><br>
    <a href="index.php"><i class="fa fa-key" aria-hidden="true"></i> Liste des apprenants </a><br>
    <a href="check_statut_cours.php?start=1"><i class="fa fa-pencil" aria-hidden="true"></i> Debuter le cours</a><br>
    <a href="check_statut_cours.php?end=2"><i class="fa fa-pencil" aria-hidden="true"></i> Fin du cours</a><br>
    <a href="teacher_profil.php?id=<?php echo $row["id"] ?>"><i class="fa fa-bullhorn" aria-hidden="true"></i> Mon profil</a><br>
    <a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Déconnexion</a><br>
  </div>

    <div class="main">
      <p>
        
        <div class="text-uppercase">
          <center>Bienvenue Proffesseur: <strong> <?php echo $nometprenoms ; ?> </strong></center> <br></br>
        </div>
           
      </p>
  </div>

</body>
</html> 
